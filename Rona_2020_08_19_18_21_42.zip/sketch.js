function setup() {
  createCanvas(900, 800);

}

function draw() {
  
  corona(400,400)
  
function corona(xpos,ypos){
  fill(0,0,0);
  line( 300, 400, 500, 400) 
  line( 400, 300, 400, 500) 
  line(310,310,490,490)
  line(310,490,490,310)
  fill(200,0,100)
  circle(300,300,30)
  circle(400,300,30)
  circle(300,400,30)
  circle(300,500,30)
  circle(500,500,30)
  circle(500,300,30)
 circle(400,500,30)
  circle(500,400,30)
  
   circle(xpos,ypos,150);
  fill(0,200,0);
 circle(369,370,30);
  circle(430,370,30);
  fill(00,0,0);
  translate(width / 2, height / 40);
  rotate(PI / 3.0);
  translate(width / 2, height / 40);
  rotate(PI / 3.0);
 circle(140,215,75);

}
}

