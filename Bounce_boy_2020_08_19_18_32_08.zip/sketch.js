let speed = 10
let xpos = 300
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(1);
  fill(1, 260, 1)
  circle(xpos, 200, 100);
  if(xpos> width) {speed = speed *-1
}
  if(xpos<0) { speed = speed *-1 }
xpos += speed
}